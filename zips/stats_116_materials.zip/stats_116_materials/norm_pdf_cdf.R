z <- seq(-4, 4, by=0.01)
par(mfrow=c(1,2))
plot(z, dnorm(z), ylab="", type="l", lwd=2, col="red", main="Standard normal PDF")
plot(z, pnorm(z), ylab="", type="l", lwd=2, col="blue", main="Standard normal CDF")


# Bernoulli(p) CDF
p <- 0.6
plot(-1:2, seq(0,1,length.out=4), xlab="x", ylab="", type="n")
segments(-5, 0, 0, 0)
segments(0, 1-p, 1, 1-p)
segments(1, 1, 5, 1)
points(0, 0, pch=1)
points(0, 1-p, pch=16)
points(1, 1-p, pch=1)
points(1, 1, pch=16)